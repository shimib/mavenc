Apache Maven 3.2.1 (ea8b2b07643dbb1b84b6d16e1f08391b666bc1e9; 2014-02-14T19:37:52+02:00)
Maven home: f:\frameworks\apache-maven-3.2.1
Java version: 1.8.0_25, vendor: Oracle Corporation
Java home: c:\Program Files\Java\jdk1.8.0_25\jre
Default locale: en_GB, platform encoding: Cp1252
OS name: "windows 8.1", version: "6.3", arch: "amd64", family: "dos"
[INFO] Error stacktraces are turned on.
[DEBUG] Reading global settings from f:\frameworks\apache-maven-3.2.1\conf\settings.xml
[DEBUG] Reading user settings from C:\Users\Shimi Bandiel\.m2\settings.xml
[DEBUG] Using local repository at C:\Users\Shimi Bandiel\.m2\repository
[DEBUG] Using manager EnhancedLocalRepositoryManager with priority 10.0 for C:\Users\Shimi Bandiel\.m2\repository
[INFO] Scanning for projects...
[DEBUG] Extension realms for project com.bom:MyTest:jar:1.0-SNAPSHOT: (none)
[DEBUG] Looking up lifecyle mappings for packaging jar from ClassRealm[plexus.core, parent: null]
[DEBUG] === REACTOR BUILD PLAN ================================================
[DEBUG] Project: com.bom:MyTest:jar:1.0-SNAPSHOT
[DEBUG] Tasks:   [clean, install]
[DEBUG] Style:   Regular
[DEBUG] =======================================================================
[INFO] 
[INFO] Using the builder org.apache.maven.lifecycle.internal.builder.singlethreaded.SingleThreadedBuilder with a thread count of 1
[INFO]                                                                         
[INFO] ------------------------------------------------------------------------
[INFO] Building MyMojojo Maven Mojo 1.0-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] Lifecycle default -> [validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy]
[DEBUG] Lifecycle clean -> [pre-clean, clean, post-clean]
[DEBUG] Lifecycle site -> [pre-site, site, post-site, site-deploy]
[DEBUG] === PROJECT BUILD PLAN ================================================
[DEBUG] Project:       com.bom:MyTest:1.0-SNAPSHOT
[DEBUG] Dependencies (collect): []
[DEBUG] Dependencies (resolve): [compile, runtime, test]
[DEBUG] Repositories (dependencies): [central (http://repo.maven.apache.org/maven2, releases)]
[DEBUG] Repositories (plugins)     : [central (http://repo.maven.apache.org/maven2, releases)]
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-clean-plugin:2.5:clean (default-clean)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <directory default-value="${project.build.directory}"/>
  <excludeDefaultDirectories default-value="false">${clean.excludeDefaultDirectories}</excludeDefaultDirectories>
  <failOnError default-value="true">${maven.clean.failOnError}</failOnError>
  <followSymLinks default-value="false">${clean.followSymLinks}</followSymLinks>
  <outputDirectory default-value="${project.build.outputDirectory}"/>
  <reportDirectory default-value="${project.reporting.outputDirectory}"/>
  <retryOnError default-value="true">${maven.clean.retryOnError}</retryOnError>
  <skip default-value="false">${clean.skip}</skip>
  <testOutputDirectory default-value="${project.build.testOutputDirectory}"/>
  <verbose>${clean.verbose}</verbose>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-resources-plugin:2.6:resources (default-resources)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <buildFilters default-value="${project.build.filters}"/>
  <encoding default-value="${project.build.sourceEncoding}">${encoding}</encoding>
  <escapeString>${maven.resources.escapeString}</escapeString>
  <escapeWindowsPaths default-value="true">${maven.resources.escapeWindowsPaths}</escapeWindowsPaths>
  <includeEmptyDirs default-value="false">${maven.resources.includeEmptyDirs}</includeEmptyDirs>
  <outputDirectory default-value="${project.build.outputDirectory}"/>
  <overwrite default-value="false">${maven.resources.overwrite}</overwrite>
  <project default-value="${project}"/>
  <resources default-value="${project.resources}"/>
  <session default-value="${session}"/>
  <supportMultiLineFiltering default-value="false">${maven.resources.supportMultiLineFiltering}</supportMultiLineFiltering>
  <useBuildFilters default-value="true"/>
  <useDefaultDelimiters default-value="true"/>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-compiler-plugin:2.5.1:compile (default-compile)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <basedir default-value="${basedir}"/>
  <buildDirectory default-value="${project.build.directory}"/>
  <classpathElements default-value="${project.compileClasspathElements}"/>
  <compileSourceRoots default-value="${project.compileSourceRoots}"/>
  <compilerId default-value="javac">${maven.compiler.compilerId}</compilerId>
  <compilerReuseStrategy default-value="${reuseCreated}">${maven.compiler.compilerReuseStrategy}</compilerReuseStrategy>
  <compilerVersion>${maven.compiler.compilerVersion}</compilerVersion>
  <debug default-value="true">${maven.compiler.debug}</debug>
  <debuglevel>${maven.compiler.debuglevel}</debuglevel>
  <encoding default-value="${project.build.sourceEncoding}">${encoding}</encoding>
  <executable>${maven.compiler.executable}</executable>
  <failOnError default-value="true">${maven.compiler.failOnError}</failOnError>
  <fork default-value="false">${maven.compiler.fork}</fork>
  <generatedSourcesDirectory default-value="${project.build.directory}/generated-sources/annotations"/>
  <maxmem>${maven.compiler.maxmem}</maxmem>
  <meminitial>${maven.compiler.meminitial}</meminitial>
  <optimize default-value="false">${maven.compiler.optimize}</optimize>
  <outputDirectory default-value="${project.build.outputDirectory}"/>
  <outputFileName>${project.build.finalName}</outputFileName>
  <projectArtifact default-value="${project.artifact}"/>
  <session default-value="${session}"/>
  <showDeprecation default-value="false">${maven.compiler.showDeprecation}</showDeprecation>
  <showWarnings default-value="false">${maven.compiler.showWarnings}</showWarnings>
  <skipMultiThreadWarning default-value="${false}">${maven.compiler.skipMultiThreadWarning}</skipMultiThreadWarning>
  <source default-value="1.5">${maven.compiler.source}</source>
  <staleMillis default-value="0">${lastModGranularityMs}</staleMillis>
  <target default-value="1.5">${maven.compiler.target}</target>
  <verbose default-value="false">${maven.compiler.verbose}</verbose>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.codehaus.mojo:exec-maven-plugin:1.2.1:exec (first)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <arguments>
    <argument>-sjava</argument>
    <argument>-o</argument>
    <argument>-djad</argument>
    <argument>./**/*.class</argument>
  </arguments>
  <basedir default-value="${basedir}"/>
  <classpathScope default-value="runtime">${exec.classpathScope}</classpathScope>
  <commandlineArgs>${exec.args}</commandlineArgs>
  <executable>f:\\tools\\jad.exe</executable>
  <longClasspath default-value="false">${exec.longClasspath}</longClasspath>
  <outputFile>${exec.outputFile}</outputFile>
  <project default-value="${project}"/>
  <session default-value="${session}"/>
  <skip default-value="false">${skip}</skip>
  <sourceRoot>${sourceRoot}</sourceRoot>
  <testSourceRoot>${testSourceRoot}</testSourceRoot>
  <workingDirectory>target\\classes</workingDirectory>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          com.bom:MyMojojo:1.0-SNAPSHOT:tail-rec-optimize (default)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <outputDirectory>${project.build.directory}</outputDirectory>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-resources-plugin:2.6:testResources (default-testResources)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <buildFilters default-value="${project.build.filters}"/>
  <encoding default-value="${project.build.sourceEncoding}">${encoding}</encoding>
  <escapeString>${maven.resources.escapeString}</escapeString>
  <escapeWindowsPaths default-value="true">${maven.resources.escapeWindowsPaths}</escapeWindowsPaths>
  <includeEmptyDirs default-value="false">${maven.resources.includeEmptyDirs}</includeEmptyDirs>
  <outputDirectory default-value="${project.build.testOutputDirectory}"/>
  <overwrite default-value="false">${maven.resources.overwrite}</overwrite>
  <project default-value="${project}"/>
  <resources default-value="${project.testResources}"/>
  <session default-value="${session}"/>
  <skip>${maven.test.skip}</skip>
  <supportMultiLineFiltering default-value="false">${maven.resources.supportMultiLineFiltering}</supportMultiLineFiltering>
  <useBuildFilters default-value="true"/>
  <useDefaultDelimiters default-value="true"/>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-compiler-plugin:2.5.1:testCompile (default-testCompile)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <basedir default-value="${basedir}"/>
  <buildDirectory default-value="${project.build.directory}"/>
  <classpathElements default-value="${project.testClasspathElements}"/>
  <compileSourceRoots default-value="${project.testCompileSourceRoots}"/>
  <compilerId default-value="javac">${maven.compiler.compilerId}</compilerId>
  <compilerReuseStrategy default-value="${reuseCreated}">${maven.compiler.compilerReuseStrategy}</compilerReuseStrategy>
  <compilerVersion>${maven.compiler.compilerVersion}</compilerVersion>
  <debug default-value="true">${maven.compiler.debug}</debug>
  <debuglevel>${maven.compiler.debuglevel}</debuglevel>
  <encoding default-value="${project.build.sourceEncoding}">${encoding}</encoding>
  <executable>${maven.compiler.executable}</executable>
  <failOnError default-value="true">${maven.compiler.failOnError}</failOnError>
  <fork default-value="false">${maven.compiler.fork}</fork>
  <generatedTestSourcesDirectory default-value="${project.build.directory}/generated-test-sources/test-annotations"/>
  <maxmem>${maven.compiler.maxmem}</maxmem>
  <meminitial>${maven.compiler.meminitial}</meminitial>
  <optimize default-value="false">${maven.compiler.optimize}</optimize>
  <outputDirectory default-value="${project.build.testOutputDirectory}"/>
  <outputFileName>${project.build.finalName}</outputFileName>
  <session default-value="${session}"/>
  <showDeprecation default-value="false">${maven.compiler.showDeprecation}</showDeprecation>
  <showWarnings default-value="false">${maven.compiler.showWarnings}</showWarnings>
  <skip>${maven.test.skip}</skip>
  <skipMultiThreadWarning default-value="${false}">${maven.compiler.skipMultiThreadWarning}</skipMultiThreadWarning>
  <source default-value="1.5">${maven.compiler.source}</source>
  <staleMillis default-value="0">${lastModGranularityMs}</staleMillis>
  <target default-value="1.5">${maven.compiler.target}</target>
  <testSource>${maven.compiler.testSource}</testSource>
  <testTarget>${maven.compiler.testTarget}</testTarget>
  <verbose default-value="false">${maven.compiler.verbose}</verbose>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-surefire-plugin:2.12.4:test (default-test)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <argLine>${argLine}</argLine>
  <basedir default-value="${basedir}"/>
  <childDelegation default-value="false">${childDelegation}</childDelegation>
  <classesDirectory default-value="${project.build.outputDirectory}"/>
  <debugForkedProcess>${maven.surefire.debug}</debugForkedProcess>
  <disableXmlReport default-value="false">${disableXmlReport}</disableXmlReport>
  <enableAssertions default-value="true">${enableAssertions}</enableAssertions>
  <excludedGroups>${excludedGroups}</excludedGroups>
  <failIfNoSpecifiedTests>${surefire.failIfNoSpecifiedTests}</failIfNoSpecifiedTests>
  <failIfNoTests>${failIfNoTests}</failIfNoTests>
  <forkMode default-value="once">${forkMode}</forkMode>
  <forkedProcessTimeoutInSeconds>${surefire.timeout}</forkedProcessTimeoutInSeconds>
  <groups>${groups}</groups>
  <junitArtifactName default-value="junit:junit">${junitArtifactName}</junitArtifactName>
  <jvm>${jvm}</jvm>
  <localRepository default-value="${localRepository}"/>
  <objectFactory>${objectFactory}</objectFactory>
  <parallel>${parallel}</parallel>
  <parallelMavenExecution default-value="${session.parallel}"/>
  <perCoreThreadCount default-value="true">${perCoreThreadCount}</perCoreThreadCount>
  <pluginArtifactMap>${plugin.artifactMap}</pluginArtifactMap>
  <pluginDescriptor default-value="${plugin}"/>
  <printSummary default-value="true">${surefire.printSummary}</printSummary>
  <projectArtifactMap>${project.artifactMap}</projectArtifactMap>
  <redirectTestOutputToFile default-value="false">${maven.test.redirectTestOutputToFile}</redirectTestOutputToFile>
  <remoteRepositories default-value="${project.pluginArtifactRepositories}"/>
  <reportFormat default-value="brief">${surefire.reportFormat}</reportFormat>
  <reportNameSuffix default-value="">${surefire.reportNameSuffix}</reportNameSuffix>
  <reportsDirectory default-value="${project.build.directory}/surefire-reports"/>
  <runOrder default-value="filesystem"/>
  <skip default-value="false">${maven.test.skip}</skip>
  <skipExec>${maven.test.skip.exec}</skipExec>
  <skipTests default-value="false">${skipTests}</skipTests>
  <test>${test}</test>
  <testClassesDirectory default-value="${project.build.testOutputDirectory}"/>
  <testFailureIgnore default-value="false">${maven.test.failure.ignore}</testFailureIgnore>
  <testNGArtifactName default-value="org.testng:testng">${testNGArtifactName}</testNGArtifactName>
  <testSourceDirectory default-value="${project.build.testSourceDirectory}"/>
  <threadCount>${threadCount}</threadCount>
  <trimStackTrace default-value="true">${trimStackTrace}</trimStackTrace>
  <useFile default-value="true">${surefire.useFile}</useFile>
  <useManifestOnlyJar default-value="true">${surefire.useManifestOnlyJar}</useManifestOnlyJar>
  <useSystemClassLoader default-value="true">${surefire.useSystemClassLoader}</useSystemClassLoader>
  <useUnlimitedThreads default-value="false">${useUnlimitedThreads}</useUnlimitedThreads>
  <workingDirectory>${basedir}</workingDirectory>
  <project default-value="${project}"/>
  <session default-value="${session}"/>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.codehaus.mojo:exec-maven-plugin:1.2.1:exec (second)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <arguments>
    <argument>-sjava</argument>
    <argument>-o</argument>
    <argument>-djad2</argument>
    <argument>./**/*.class</argument>
  </arguments>
  <basedir default-value="${basedir}"/>
  <classpathScope default-value="runtime">${exec.classpathScope}</classpathScope>
  <commandlineArgs>${exec.args}</commandlineArgs>
  <executable>f:\\tools\\jad.exe</executable>
  <longClasspath default-value="false">${exec.longClasspath}</longClasspath>
  <outputFile>${exec.outputFile}</outputFile>
  <project default-value="${project}"/>
  <session default-value="${session}"/>
  <skip default-value="false">${skip}</skip>
  <sourceRoot>${sourceRoot}</sourceRoot>
  <testSourceRoot>${testSourceRoot}</testSourceRoot>
  <workingDirectory>target\\classes</workingDirectory>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.codehaus.mojo:exec-maven-plugin:1.2.1:exec (third)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <arguments>
    <argument>jad</argument>
    <argument>jad2</argument>
  </arguments>
  <basedir default-value="${basedir}"/>
  <classpathScope default-value="runtime">${exec.classpathScope}</classpathScope>
  <commandlineArgs>${exec.args}</commandlineArgs>
  <executable>c:\Program Files (x86)\GnuWin32\bin\diff.exe</executable>
  <longClasspath default-value="false">${exec.longClasspath}</longClasspath>
  <outputFile>TailOptReport.txt</outputFile>
  <project default-value="${project}"/>
  <session default-value="${session}"/>
  <skip default-value="false">${skip}</skip>
  <sourceRoot>${sourceRoot}</sourceRoot>
  <successCodes>
    <successCode>0</successCode>
    <successCode>1</successCode>
  </successCodes>
  <testSourceRoot>${testSourceRoot}</testSourceRoot>
  <workingDirectory>target\classes</workingDirectory>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-jar-plugin:2.4:jar (default-jar)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <classesDirectory default-value="${project.build.outputDirectory}"/>
  <defaultManifestFile default-value="${project.build.outputDirectory}/META-INF/MANIFEST.MF"/>
  <finalName default-value="${project.build.finalName}">${jar.finalName}</finalName>
  <forceCreation default-value="false">${jar.forceCreation}</forceCreation>
  <outputDirectory default-value="${project.build.directory}"/>
  <project default-value="${project}"/>
  <session default-value="${session}"/>
  <skipIfEmpty default-value="false">${jar.skipIfEmpty}</skipIfEmpty>
  <useDefaultManifestFile default-value="false">${jar.useDefaultManifestFile}</useDefaultManifestFile>
</configuration>
[DEBUG] -----------------------------------------------------------------------
[DEBUG] Goal:          org.apache.maven.plugins:maven-install-plugin:2.4:install (default-install)
[DEBUG] Style:         Regular
[DEBUG] Configuration: <?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <artifact default-value="${project.artifact}"/>
  <attachedArtifacts default-value="${project.attachedArtifacts}"/>
  <createChecksum default-value="false">${createChecksum}</createChecksum>
  <localRepository>${localRepository}</localRepository>
  <packaging default-value="${project.packaging}"/>
  <pomFile default-value="${project.file}"/>
  <skip default-value="false">${maven.install.skip}</skip>
  <updateReleaseInfo default-value="false">${updateReleaseInfo}</updateReleaseInfo>
</configuration>
[DEBUG] =======================================================================
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=1, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=1, ConflictIdSorter.conflictIdCount=0, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=0, DefaultDependencyCollector.collectTime=0, DefaultDependencyCollector.transformTime=4}
[DEBUG] com.bom:MyTest:jar:1.0-SNAPSHOT
[INFO] 
[INFO] --- maven-clean-plugin:2.5:clean (default-clean) @ MyTest ---
[DEBUG] Created new class realm maven.api
[DEBUG] Importing foreign packages into class realm maven.api
[DEBUG]   Imported: org.apache.maven.cli < plexus.core
[DEBUG]   Imported: org.eclipse.aether.internal.impl < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.lifecycle < plexus.core
[DEBUG]   Imported: org.apache.maven.lifecycle < plexus.core
[DEBUG]   Imported: org.apache.maven.repository < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.personality < plexus.core
[DEBUG]   Imported: org.apache.maven.usability < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.configuration < plexus.core
[DEBUG]   Imported: javax.enterprise.inject.* < plexus.core
[DEBUG]   Imported: org.apache.maven.* < plexus.core
[DEBUG]   Imported: org.apache.maven.project < plexus.core
[DEBUG]   Imported: org.apache.maven.exception < plexus.core
[DEBUG]   Imported: org.eclipse.aether.spi < plexus.core
[DEBUG]   Imported: org.apache.maven.plugin < plexus.core
[DEBUG]   Imported: org.eclipse.aether.collection < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.* < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.logging < plexus.core
[DEBUG]   Imported: org.apache.maven.profiles < plexus.core
[DEBUG]   Imported: org.eclipse.aether.transfer < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.util.xml.pull.XmlPullParserException < plexus.core
[DEBUG]   Imported: org.apache.maven.execution.scope < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.* < plexus.core
[DEBUG]   Imported: org.apache.maven.rtinfo < plexus.core
[DEBUG]   Imported: org.eclipse.aether.impl < plexus.core
[DEBUG]   Imported: org.apache.maven.monitor < plexus.core
[DEBUG]   Imported: org.eclipse.aether.graph < plexus.core
[DEBUG]   Imported: org.eclipse.aether.metadata < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.context < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.observers < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.resource < plexus.core
[DEBUG]   Imported: javax.inject.* < plexus.core
[DEBUG]   Imported: org.apache.maven.model < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.util.xml.Xpp3Dom < plexus.core
[DEBUG]   Imported: org.eclipse.aether.deployment < plexus.core
[DEBUG]   Imported: org.apache.maven.artifact < plexus.core
[DEBUG]   Imported: org.apache.maven.toolchain < plexus.core
[DEBUG]   Imported: org.eclipse.aether.resolution < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.util.xml.pull.XmlSerializer < plexus.core
[DEBUG]   Imported: org.apache.maven.settings < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.authorization < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.events < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.authentication < plexus.core
[DEBUG]   Imported: org.apache.maven.reporting < plexus.core
[DEBUG]   Imported: org.eclipse.aether.repository < plexus.core
[DEBUG]   Imported: org.slf4j.* < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.repository < plexus.core
[DEBUG]   Imported: org.apache.maven.configuration < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.classworlds < plexus.core
[DEBUG]   Imported: org.codehaus.classworlds < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.util.xml.pull.XmlPullParser < plexus.core
[DEBUG]   Imported: org.apache.maven.classrealm < plexus.core
[DEBUG]   Imported: org.eclipse.aether.* < plexus.core
[DEBUG]   Imported: org.eclipse.aether.artifact < plexus.core
[DEBUG]   Imported: org.apache.maven.execution < plexus.core
[DEBUG]   Imported: org.apache.maven.wagon.proxy < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.container < plexus.core
[DEBUG]   Imported: org.eclipse.aether.version < plexus.core
[DEBUG]   Imported: org.eclipse.aether.installation < plexus.core
[DEBUG]   Imported: org.codehaus.plexus.component < plexus.core
[DEBUG] Populating class realm maven.api
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=1, ConflictMarker.markTime=0, ConflictMarker.nodeCount=3, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=3, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=3, DefaultDependencyCollector.collectTime=19, DefaultDependencyCollector.transformTime=2}
[DEBUG] org.apache.maven.plugins:maven-clean-plugin:jar:2.5:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.6:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:3.0:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-clean-plugin:2.5
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-clean-plugin:2.5
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-clean-plugin:2.5
[DEBUG]   Included: org.apache.maven.plugins:maven-clean-plugin:jar:2.5
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:3.0
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.6
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-clean-plugin:2.5:clean from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-clean-plugin:2.5, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-clean-plugin:2.5:clean' with basic configurator -->
[DEBUG]   (f) directory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG]   (f) excludeDefaultDirectories = false
[DEBUG]   (f) failOnError = true
[DEBUG]   (f) followSymLinks = false
[DEBUG]   (f) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG]   (f) reportDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\site
[DEBUG]   (f) retryOnError = true
[DEBUG]   (f) skip = false
[DEBUG]   (f) testOutputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes
[DEBUG] -- end configuration --
[INFO] Deleting C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\MyTest-1.0-SNAPSHOT.jar
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\maven-archiver\pom.properties
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\maven-archiver
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad2\ShowRec.java
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad2\MyFactorial.java
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad2
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad\ShowRec.java
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad\MyFactorial.java
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\jad
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\com\ShowRec.class
[INFO] Deleting file C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\com\MyFactorial.class
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\com
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[INFO] Deleting directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG] Skipping non-existing directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] Skipping non-existing directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes
[DEBUG] Skipping non-existing directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\site
[INFO] 
[INFO] --- maven-resources-plugin:2.6:resources (default-resources) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=77, ConflictIdSorter.graphTime=1, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=26, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=74, DefaultDependencyCollector.collectTime=102, DefaultDependencyCollector.transformTime=2}
[DEBUG] org.apache.maven.plugins:maven-resources-plugin:jar:2.6:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-project:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-artifact-manager:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-registry:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-core:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6:compile
[DEBUG]       org.apache.maven.reporting:maven-reporting-api:jar:2.0.6:compile
[DEBUG]          org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7:compile
[DEBUG]       org.apache.maven:maven-repository-metadata:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-error-diagnostics:jar:2.0.6:compile
[DEBUG]       commons-cli:commons-cli:jar:1.0:compile
[DEBUG]       org.apache.maven:maven-plugin-descriptor:jar:2.0.6:compile
[DEBUG]       org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4:compile
[DEBUG]       classworlds:classworlds:jar:1.1:compile
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-settings:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-model:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-monitor:jar:2.0.6:compile
[DEBUG]    org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]       junit:junit:jar:3.8.1:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:2.0.5:compile
[DEBUG]    org.apache.maven.shared:maven-filtering:jar:1.1:compile
[DEBUG]       org.sonatype.plexus:plexus-build-api:jar:0.0.4:compile
[DEBUG]    org.codehaus.plexus:plexus-interpolation:jar:1.13:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-resources-plugin:2.6
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-resources-plugin:2.6
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-resources-plugin:2.6
[DEBUG]   Included: org.apache.maven.plugins:maven-resources-plugin:jar:2.6
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-api:jar:2.0.6
[DEBUG]   Included: org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7
[DEBUG]   Included: commons-cli:commons-cli:jar:1.0
[DEBUG]   Included: org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4
[DEBUG]   Included: junit:junit:jar:3.8.1
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:2.0.5
[DEBUG]   Included: org.apache.maven.shared:maven-filtering:jar:1.1
[DEBUG]   Included: org.sonatype.plexus:plexus-build-api:jar:0.0.4
[DEBUG]   Included: org.codehaus.plexus:plexus-interpolation:jar:1.13
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-core:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-error-diagnostics:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-descriptor:jar:2.0.6
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-monitor:jar:2.0.6
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-resources-plugin:2.6:resources from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-resources-plugin:2.6, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-resources-plugin:2.6:resources' with basic configurator -->
[DEBUG]   (f) buildFilters = []
[DEBUG]   (f) escapeWindowsPaths = true
[DEBUG]   (s) includeEmptyDirs = false
[DEBUG]   (s) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG]   (s) overwrite = false
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (s) resources = [Resource {targetPath: null, filtering: false, FileSet {directory: C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\resources, PatternSet [includes: {}, excludes: {}]}}]
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) supportMultiLineFiltering = false
[DEBUG]   (f) useBuildFilters = true
[DEBUG]   (s) useDefaultDelimiters = true
[DEBUG] -- end configuration --
[DEBUG] properties used {java.vendor=Oracle Corporation, env.SYSTEMROOT=C:\WINDOWS, env.USERDOMAIN_ROAMINGPROFILE=TFWO, sun.java.launcher=SUN_STANDARD, sun.management.compiler=HotSpot 64-Bit Tiered Compilers, env.COMMANDER_DRIVE=C:, env.PROMPT=$P$G, env.COMMANDER_PATH=C:\utils\totalcmd, os.name=Windows 8.1, env.FP_NO_HOST_CHECK=NO, sun.boot.class.path=c:\Program Files\Java\jdk1.8.0_25\jre\lib\resources.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\rt.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\sunrsasign.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jsse.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jce.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\charsets.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jfr.jar;c:\Program Files\Java\jdk1.8.0_25\jre\classes, env.COMPUTERNAME=TFWO, user.country.format=IL, env.ALLUSERSPROFILE=C:\ProgramData, sun.desktop=windows, java.vm.specification.vendor=Oracle Corporation, java.runtime.version=1.8.0_25-b18, env.HOMEPATH=\Users\Shimi Bandiel, user.name=Shimi Bandiel, maven.build.version=Apache Maven 3.2.1 (ea8b2b07643dbb1b84b6d16e1f08391b666bc1e9; 2014-02-14T19:37:52+02:00), user.language.format=he, env.PATH=C:\Program Files\Haskell\bin;C:\Program Files\Haskell Platform\2014.2.0.0\lib\extralibs\bin;C:\Program Files\Haskell Platform\2014.2.0.0\bin;C:\Program Files (x86)\Chez Scheme Version 8.4\bin\i3nt;C:\ProgramData\Oracle\Java\javapath;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;c:\Program Files (x86)\scala\bin\;C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Windows Live\Shared;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\sbt\\bin;c:\Python27;f:\frameworks\graphviz-2.38\release\bin;C:\HashiCorp\Vagrant\bin;C:\opscode\chefdk\bin;C:\Program Files\Haskell Platform\2014.2.0.0\mingw\bin;C:\Program Files\nodejs\;C:\Program Files (x86)\Skype\Phone\;C:\Users\Shimi Bandiel\AppData\Roaming\cabal\bin;C:\Program Files\Boot2Docker for Windows;C:\Users\Shimi Bandiel\AppData\Roaming\npm;f:\frameworks\apache-maven-3.2.1\bin;f:\tools, user.language=en, env.SBT_HOME=C:\Program Files (x86)\sbt\, env.WINDIR=C:\WINDOWS, sun.boot.library.path=c:\Program Files\Java\jdk1.8.0_25\jre\bin, classworlds.conf=f:\frameworks\apache-maven-3.2.1\bin\m2.conf, java.version=1.8.0_25, env.PROCESSOR_IDENTIFIER=Intel64 Family 6 Model 60 Stepping 3, GenuineIntel, user.timezone=Asia/Jerusalem, env.TEMP=C:\Users\SHIMIB~1\AppData\Local\Temp, sun.arch.data.model=64, env.EC2_HOME=f:\frameworks\ec2-api-tools-1.7.1.0, java.endorsed.dirs=c:\Program Files\Java\jdk1.8.0_25\jre\lib\endorsed, sun.cpu.isalist=amd64, env.HOMEDRIVE=C:, sun.jnu.encoding=Cp1252, file.encoding.pkg=sun.io, env.SYSTEMDRIVE=C:, file.separator=\, java.specification.name=Java Platform API Specification, java.class.version=52.0, org.slf4j.simpleLogger.defaultLogLevel=debug, user.country=GB, java.home=c:\Program Files\Java\jdk1.8.0_25\jre, env.APPDATA=C:\Users\Shimi Bandiel\AppData\Roaming, env.CONFIGSETROOT=C:\WINDOWS\ConfigSetRoot, env.PUBLIC=C:\Users\Public, java.vm.info=mixed mode, env.OS=Windows_NT, os.version=6.3, path.separator=;, java.vm.version=25.25-b02, env.COMMANDER_EXE=C:\utils\totalcmd\TOTALCMD64.EXE, env.ASL.LOG=Destination=file, user.variant=, env.USERPROFILE=C:\Users\Shimi Bandiel, env.=F:=f:\Dropbox\Hibernate, env.JAVA_HOME=c:\Program Files\Java\jdk1.8.0_25, java.awt.printerjob=sun.awt.windows.WPrinterJob, env.TMP=C:\Users\SHIMIB~1\AppData\Local\Temp, env.PROGRAMFILES=C:\Program Files, sun.io.unicode.encoding=UnicodeLittle, awt.toolkit=sun.awt.windows.WToolkit, user.script=, user.home=C:\Users\Shimi Bandiel, env.COMMONPROGRAMFILES=C:\Program Files\Common Files, env.=EXITCODE=00000000, env.SESSIONNAME=Console, java.specification.vendor=Oracle Corporation, env.M2_HOME=f:\frameworks\apache-maven-3.2.1, java.library.path=c:\Program Files\Java\jdk1.8.0_25\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files\Haskell\bin;C:\Program Files\Haskell Platform\2014.2.0.0\lib\extralibs\bin;C:\Program Files\Haskell Platform\2014.2.0.0\bin;C:\Program Files (x86)\Chez Scheme Version 8.4\bin\i3nt;C:\ProgramData\Oracle\Java\javapath;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;c:\Program Files (x86)\scala\bin\;C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Windows Live\Shared;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\sbt\\bin;c:\Python27;f:\frameworks\graphviz-2.38\release\bin;C:\HashiCorp\Vagrant\bin;C:\opscode\chefdk\bin;C:\Program Files\Haskell Platform\2014.2.0.0\mingw\bin;C:\Program Files\nodejs\;C:\Program Files (x86)\Skype\Phone\;C:\Users\Shimi Bandiel\AppData\Roaming\cabal\bin;C:\Program Files\Boot2Docker for Windows;C:\Users\Shimi Bandiel\AppData\Roaming\npm;f:\frameworks\apache-maven-3.2.1\bin;f:\tools;., env.NUMBER_OF_PROCESSORS=8, java.vendor.url=http://java.oracle.com/, env.COMMONPROGRAMFILES(X86)=C:\Program Files (x86)\Common Files, env.PSMODULEPATH=C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules\, env.CLASSWORLDS_LAUNCHER=org.codehaus.plexus.classworlds.launcher.Launcher, env.MAVEN_CMD_LINE_ARGS=-X clean install, java.vm.vendor=Oracle Corporation, maven.home=f:\frameworks\apache-maven-3.2.1, java.runtime.name=Java(TM) SE Runtime Environment, sun.java.command=org.codehaus.plexus.classworlds.launcher.Launcher -X clean install, java.class.path=f:\frameworks\apache-maven-3.2.1\boot\plexus-classworlds-2.5.1.jar, env.PROGRAMW6432=C:\Program Files, maven.version=3.2.1, env.PROGRAMFILES(X86)=C:\Program Files (x86), env.MAVEN_JAVA_EXE="c:\Program Files\Java\jdk1.8.0_25\bin\java.exe", java.vm.specification.name=Java Virtual Machine Specification, env.LOGONSERVER=\\MicrosoftAccount, java.vm.specification.version=1.8, env.PROCESSOR_ARCHITECTURE=AMD64, env.COMMONPROGRAMW6432=C:\Program Files\Common Files, sun.cpu.endian=little, sun.os.patch.level=, env.HOME=C:\Users\Shimi Bandiel, java.io.tmpdir=C:\Users\SHIMIB~1\AppData\Local\Temp\, env.PROCESSOR_REVISION=3c03, env.VBOX_INSTALL_PATH=C:\Program Files\Oracle\VirtualBox\, java.vendor.url.bug=http://bugreport.sun.com/bugreport/, env.PROGRAMDATA=C:\ProgramData, env.COMSPEC=C:\WINDOWS\system32\cmd.exe, os.arch=amd64, java.awt.graphicsenv=sun.awt.Win32GraphicsEnvironment, java.ext.dirs=c:\Program Files\Java\jdk1.8.0_25\jre\lib\ext;C:\WINDOWS\Sun\Java\lib\ext, user.dir=C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec, env.LOCALAPPDATA=C:\Users\Shimi Bandiel\AppData\Local, line.separator=
, env.CLASSWORLDS_JAR="f:\frameworks\apache-maven-3.2.1\boot\plexus-classworlds-2.5.1.jar", java.vm.name=Java HotSpot(TM) 64-Bit Server VM, env.PATHEXT=.COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC, env.M2=f:\frameworks\apache-maven-3.2.1\bin, env.ERROR_CODE=0, env.USERNAME=Shimi Bandiel, sun.stderr.encoding=cp437, file.encoding=Cp1252, env.USERDOMAIN=TFWO, env.COMMANDER_INI=C:\Users\Shimi Bandiel\AppData\Roaming\GHISLER\wincmd.ini, java.specification.version=1.8, env.=C:=C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec, env.PROCESSOR_LEVEL=6}
[WARNING] Using platform encoding (Cp1252 actually) to copy filtered resources, i.e. build is platform dependent!
[DEBUG] resource with targetPath null
directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\resources
excludes []
includes []
[INFO] skip non existing resourceDirectory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\resources
[DEBUG] no use filter components
[INFO] 
[INFO] --- maven-compiler-plugin:2.5.1:compile (default-compile) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=106, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=27, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=53, DefaultDependencyCollector.collectTime=76, DefaultDependencyCollector.transformTime=1}
[DEBUG] org.apache.maven.plugins:maven-compiler-plugin:jar:2.5.1:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.9:compile
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.9:compile
[DEBUG]    org.apache.maven:maven-core:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-settings:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-model:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-repository-metadata:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-error-diagnostics:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-project:jar:2.0.9:compile
[DEBUG]          org.apache.maven:maven-plugin-registry:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-plugin-descriptor:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-artifact-manager:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-monitor:jar:2.0.9:compile
[DEBUG]    org.apache.maven:maven-toolchain:jar:1.0:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:3.0:compile
[DEBUG]    org.codehaus.plexus:plexus-compiler-api:jar:1.9.1:compile
[DEBUG]    org.codehaus.plexus:plexus-compiler-manager:jar:1.9.1:compile
[DEBUG]    org.codehaus.plexus:plexus-compiler-javac:jar:1.9.1:runtime
[DEBUG]    org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]       junit:junit:jar:3.8.1:compile
[DEBUG]       classworlds:classworlds:jar:1.1-alpha-2:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-compiler-plugin:2.5.1
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-compiler-plugin:2.5.1
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-compiler-plugin:2.5.1
[DEBUG]   Included: org.apache.maven.plugins:maven-compiler-plugin:jar:2.5.1
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:3.0
[DEBUG]   Included: org.codehaus.plexus:plexus-compiler-api:jar:1.9.1
[DEBUG]   Included: org.codehaus.plexus:plexus-compiler-manager:jar:1.9.1
[DEBUG]   Included: org.codehaus.plexus:plexus-compiler-javac:jar:1.9.1
[DEBUG]   Included: junit:junit:jar:3.8.1
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-core:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-error-diagnostics:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-descriptor:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-monitor:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-toolchain:jar:1.0
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1-alpha-2
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-compiler-plugin:2.5.1:compile from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-compiler-plugin:2.5.1, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-compiler-plugin:2.5.1:compile' with basic configurator -->
[DEBUG]   (f) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (f) buildDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG]   (f) classpathElements = [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes]
[DEBUG]   (f) compileSourceRoots = [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java]
[DEBUG]   (f) compilerId = javac
[DEBUG]   (f) debug = true
[DEBUG]   (f) failOnError = true
[DEBUG]   (f) fork = false
[DEBUG]   (f) generatedSourcesDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\generated-sources\annotations
[DEBUG]   (f) optimize = false
[DEBUG]   (f) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG]   (f) outputFileName = MyTest-1.0-SNAPSHOT
[DEBUG]   (f) projectArtifact = com.bom:MyTest:jar:1.0-SNAPSHOT
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) showDeprecation = false
[DEBUG]   (f) showWarnings = false
[DEBUG]   (f) source = 1.5
[DEBUG]   (f) staleMillis = 0
[DEBUG]   (f) target = 1.5
[DEBUG]   (f) verbose = false
[DEBUG] -- end configuration --
[DEBUG] Using compiler 'javac'.
[DEBUG] Source directories: [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java]
[DEBUG] Classpath: [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes]
[DEBUG] Output directory: C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] CompilerReuseStrategy: reuseCreated
[DEBUG] Classpath:
[DEBUG]  C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] Source roots:
[DEBUG]  C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java
[DEBUG] Command line options:
[DEBUG] -d C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes -classpath C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes; -sourcepath C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java; C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java\com\ShowRec.java C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\main\java\com\MyFactorial.java -g -nowarn -target 1.5 -source 1.5
[WARNING] File encoding has not been set, using platform encoding Cp1252, i.e. build is platform dependent!
[INFO] Compiling 2 source files to C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[INFO] 
[INFO] --- exec-maven-plugin:1.2.1:exec (first) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=1, ConflictMarker.markTime=0, ConflictMarker.nodeCount=68, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=25, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=0, ConflictResolver.conflictItemCount=65, DefaultDependencyCollector.collectTime=26, DefaultDependencyCollector.transformTime=1}
[DEBUG] org.codehaus.mojo:exec-maven-plugin:jar:1.2.1:
[DEBUG]    org.apache.maven:maven-toolchain:jar:1.0:compile
[DEBUG]    org.apache.maven:maven-project:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-settings:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-registry:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-model:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-artifact-manager:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-repository-metadata:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-core:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6:compile
[DEBUG]       org.apache.maven.reporting:maven-reporting-api:jar:2.0.6:compile
[DEBUG]          org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7:compile
[DEBUG]       org.apache.maven:maven-error-diagnostics:jar:2.0.6:compile
[DEBUG]       commons-cli:commons-cli:jar:1.0:compile
[DEBUG]       org.apache.maven:maven-plugin-descriptor:jar:2.0.6:compile
[DEBUG]       org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4:compile
[DEBUG]       org.apache.maven:maven-monitor:jar:2.0.6:compile
[DEBUG]       classworlds:classworlds:jar:1.1:compile
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.6:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:2.0.5:compile
[DEBUG]    org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9:compile
[DEBUG]       junit:junit:jar:3.8.2:test
[DEBUG]    org.apache.commons:commons-exec:jar:1.1:compile
[DEBUG] Created new class realm plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1
[DEBUG] Importing foreign packages into class realm plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1
[DEBUG]   Included: org.codehaus.mojo:exec-maven-plugin:jar:1.2.1
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-api:jar:2.0.6
[DEBUG]   Included: org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7
[DEBUG]   Included: commons-cli:commons-cli:jar:1.0
[DEBUG]   Included: org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:2.0.5
[DEBUG]   Included: org.apache.commons:commons-exec:jar:1.1
[DEBUG]   Excluded: org.apache.maven:maven-toolchain:jar:1.0
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-core:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-error-diagnostics:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-descriptor:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-monitor:jar:2.0.6
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.6
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9
[DEBUG]   Excluded: junit:junit:jar:3.8.2
[DEBUG] Configuring mojo org.codehaus.mojo:exec-maven-plugin:1.2.1:exec from plugin realm ClassRealm[plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.codehaus.mojo:exec-maven-plugin:1.2.1:exec' with basic configurator -->
[DEBUG]   (f) arguments = [-sjava, -o, -djad, ./**/*.class]
[DEBUG]   (f) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (f) classpathScope = runtime
[DEBUG]   (f) executable = f:\\tools\\jad.exe
[DEBUG]   (f) longClasspath = false
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) skip = false
[DEBUG]   (f) workingDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] -- end configuration --
[DEBUG] Toolchains are ignored, 'executable' parameter is set to f:\\tools\\jad.exe
[DEBUG] Executing command line: f:\tools\jad.exe -sjava -o -djad ./**/*.class
[INFO] 
[INFO] --- MyMojojo:1.0-SNAPSHOT:tail-rec-optimize (default) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=98, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=42, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=2, ConflictResolver.conflictItemCount=88, DefaultDependencyCollector.collectTime=164, DefaultDependencyCollector.transformTime=2}
[DEBUG] com.bom:MyMojojo:jar:1.0-SNAPSHOT:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0:compile
[DEBUG]    org.apache.maven.reporting:maven-reporting-impl:jar:2.2:compile
[DEBUG]       org.apache.maven.reporting:maven-reporting-api:jar:3.0:compile
[DEBUG]       org.apache.maven:maven-project:jar:2.2.1:compile
[DEBUG]          org.apache.maven:maven-settings:jar:2.2.1:compile
[DEBUG]          org.apache.maven:maven-profile:jar:2.2.1:compile
[DEBUG]          org.apache.maven:maven-model:jar:2.2.1:compile
[DEBUG]          org.apache.maven:maven-artifact-manager:jar:2.2.1:compile
[DEBUG]             org.apache.maven:maven-repository-metadata:jar:2.2.1:compile
[DEBUG]             backport-util-concurrent:backport-util-concurrent:jar:3.1:compile
[DEBUG]          org.apache.maven:maven-plugin-registry:jar:2.2.1:compile
[DEBUG]          org.codehaus.plexus:plexus-interpolation:jar:1.11:compile
[DEBUG]          org.apache.maven:maven-artifact:jar:2.2.1:compile
[DEBUG]          org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]             junit:junit:jar:3.8.1:compile
[DEBUG]             classworlds:classworlds:jar:1.1-alpha-2:compile
[DEBUG]       org.apache.maven.doxia:doxia-sink-api:jar:1.2:compile
[DEBUG]          org.apache.maven.doxia:doxia-logging-api:jar:1.2:compile
[DEBUG]       org.apache.maven.doxia:doxia-core:jar:1.2:compile
[DEBUG]          xerces:xercesImpl:jar:2.9.1:compile
[DEBUG]             xml-apis:xml-apis:jar:1.3.04:compile
[DEBUG]          commons-lang:commons-lang:jar:2.4:compile
[DEBUG]          org.apache.httpcomponents:httpclient:jar:4.0.2:compile
[DEBUG]             org.apache.httpcomponents:httpcore:jar:4.0.1:compile
[DEBUG]             commons-codec:commons-codec:jar:1.3:compile
[DEBUG]       org.apache.maven.doxia:doxia-site-renderer:jar:1.2:compile
[DEBUG]          org.apache.maven.doxia:doxia-decoration-model:jar:1.2:compile
[DEBUG]          org.apache.maven.doxia:doxia-module-xhtml:jar:1.2:compile
[DEBUG]          org.apache.maven.doxia:doxia-module-fml:jar:1.2:compile
[DEBUG]          org.codehaus.plexus:plexus-i18n:jar:1.0-beta-7:compile
[DEBUG]          org.codehaus.plexus:plexus-velocity:jar:1.1.7:compile
[DEBUG]          org.apache.velocity:velocity:jar:1.5:compile
[DEBUG]             oro:oro:jar:2.0.8:compile
[DEBUG]          commons-collections:commons-collections:jar:3.2.1:compile
[DEBUG]       commons-validator:commons-validator:jar:1.3.1:compile
[DEBUG]          commons-beanutils:commons-beanutils:jar:1.7.0:compile
[DEBUG]          commons-digester:commons-digester:jar:1.6:compile
[DEBUG]          commons-logging:commons-logging:jar:1.0.4:compile
[DEBUG]       org.codehaus.plexus:plexus-utils:jar:1.5.8:compile
[DEBUG]    asm:asm-all:jar:3.3.1:compile
[DEBUG] Created new class realm plugin>com.bom:MyMojojo:1.0-SNAPSHOT
[DEBUG] Importing foreign packages into class realm plugin>com.bom:MyMojojo:1.0-SNAPSHOT
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>com.bom:MyMojojo:1.0-SNAPSHOT
[DEBUG]   Included: com.bom:MyMojojo:jar:1.0-SNAPSHOT
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-impl:jar:2.2
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-api:jar:3.0
[DEBUG]   Included: backport-util-concurrent:backport-util-concurrent:jar:3.1
[DEBUG]   Included: org.codehaus.plexus:plexus-interpolation:jar:1.11
[DEBUG]   Included: junit:junit:jar:3.8.1
[DEBUG]   Included: org.apache.maven.doxia:doxia-sink-api:jar:1.2
[DEBUG]   Included: org.apache.maven.doxia:doxia-logging-api:jar:1.2
[DEBUG]   Included: org.apache.maven.doxia:doxia-core:jar:1.2
[DEBUG]   Included: xerces:xercesImpl:jar:2.9.1
[DEBUG]   Included: xml-apis:xml-apis:jar:1.3.04
[DEBUG]   Included: commons-lang:commons-lang:jar:2.4
[DEBUG]   Included: org.apache.httpcomponents:httpclient:jar:4.0.2
[DEBUG]   Included: org.apache.httpcomponents:httpcore:jar:4.0.1
[DEBUG]   Included: commons-codec:commons-codec:jar:1.3
[DEBUG]   Included: org.apache.maven.doxia:doxia-site-renderer:jar:1.2
[DEBUG]   Included: org.apache.maven.doxia:doxia-decoration-model:jar:1.2
[DEBUG]   Included: org.apache.maven.doxia:doxia-module-xhtml:jar:1.2
[DEBUG]   Included: org.apache.maven.doxia:doxia-module-fml:jar:1.2
[DEBUG]   Included: org.codehaus.plexus:plexus-i18n:jar:1.0-beta-7
[DEBUG]   Included: org.codehaus.plexus:plexus-velocity:jar:1.1.7
[DEBUG]   Included: org.apache.velocity:velocity:jar:1.5
[DEBUG]   Included: oro:oro:jar:2.0.8
[DEBUG]   Included: commons-collections:commons-collections:jar:3.2.1
[DEBUG]   Included: commons-validator:commons-validator:jar:1.3.1
[DEBUG]   Included: commons-beanutils:commons-beanutils:jar:1.7.0
[DEBUG]   Included: commons-digester:commons-digester:jar:1.6
[DEBUG]   Included: commons-logging:commons-logging:jar:1.0.4
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:1.5.8
[DEBUG]   Included: asm:asm-all:jar:3.3.1
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.2.1
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.2.1
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1-alpha-2
[DEBUG] Configuring mojo com.bom:MyMojojo:1.0-SNAPSHOT:tail-rec-optimize from plugin realm ClassRealm[plugin>com.bom:MyMojojo:1.0-SNAPSHOT, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'com.bom:MyMojojo:1.0-SNAPSHOT:tail-rec-optimize' with basic configurator -->
[DEBUG]   (f) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG] -- end configuration --
[INFO] TailRec Optimizaing: factorial
[INFO] TailRec Optimizaing: add
[INFO] 
[INFO] --- maven-resources-plugin:2.6:testResources (default-testResources) @ MyTest ---
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-resources-plugin:2.6:testResources from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-resources-plugin:2.6, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-resources-plugin:2.6:testResources' with basic configurator -->
[DEBUG]   (f) buildFilters = []
[DEBUG]   (f) escapeWindowsPaths = true
[DEBUG]   (s) includeEmptyDirs = false
[DEBUG]   (s) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes
[DEBUG]   (s) overwrite = false
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (s) resources = [Resource {targetPath: null, filtering: false, FileSet {directory: C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\test\resources, PatternSet [includes: {}, excludes: {}]}}]
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) supportMultiLineFiltering = false
[DEBUG]   (f) useBuildFilters = true
[DEBUG]   (s) useDefaultDelimiters = true
[DEBUG] -- end configuration --
[DEBUG] properties used {java.vendor=Oracle Corporation, env.SYSTEMROOT=C:\WINDOWS, env.USERDOMAIN_ROAMINGPROFILE=TFWO, sun.java.launcher=SUN_STANDARD, sun.management.compiler=HotSpot 64-Bit Tiered Compilers, env.COMMANDER_DRIVE=C:, env.PROMPT=$P$G, env.COMMANDER_PATH=C:\utils\totalcmd, os.name=Windows 8.1, env.FP_NO_HOST_CHECK=NO, sun.boot.class.path=c:\Program Files\Java\jdk1.8.0_25\jre\lib\resources.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\rt.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\sunrsasign.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jsse.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jce.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\charsets.jar;c:\Program Files\Java\jdk1.8.0_25\jre\lib\jfr.jar;c:\Program Files\Java\jdk1.8.0_25\jre\classes, env.COMPUTERNAME=TFWO, user.country.format=IL, env.ALLUSERSPROFILE=C:\ProgramData, sun.desktop=windows, java.vm.specification.vendor=Oracle Corporation, java.runtime.version=1.8.0_25-b18, env.HOMEPATH=\Users\Shimi Bandiel, user.name=Shimi Bandiel, maven.build.version=Apache Maven 3.2.1 (ea8b2b07643dbb1b84b6d16e1f08391b666bc1e9; 2014-02-14T19:37:52+02:00), user.language.format=he, env.PATH=C:\Program Files\Haskell\bin;C:\Program Files\Haskell Platform\2014.2.0.0\lib\extralibs\bin;C:\Program Files\Haskell Platform\2014.2.0.0\bin;C:\Program Files (x86)\Chez Scheme Version 8.4\bin\i3nt;C:\ProgramData\Oracle\Java\javapath;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;c:\Program Files (x86)\scala\bin\;C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Windows Live\Shared;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\sbt\\bin;c:\Python27;f:\frameworks\graphviz-2.38\release\bin;C:\HashiCorp\Vagrant\bin;C:\opscode\chefdk\bin;C:\Program Files\Haskell Platform\2014.2.0.0\mingw\bin;C:\Program Files\nodejs\;C:\Program Files (x86)\Skype\Phone\;C:\Users\Shimi Bandiel\AppData\Roaming\cabal\bin;C:\Program Files\Boot2Docker for Windows;C:\Users\Shimi Bandiel\AppData\Roaming\npm;f:\frameworks\apache-maven-3.2.1\bin;f:\tools, user.language=en, env.SBT_HOME=C:\Program Files (x86)\sbt\, env.WINDIR=C:\WINDOWS, sun.boot.library.path=c:\Program Files\Java\jdk1.8.0_25\jre\bin, classworlds.conf=f:\frameworks\apache-maven-3.2.1\bin\m2.conf, java.version=1.8.0_25, env.PROCESSOR_IDENTIFIER=Intel64 Family 6 Model 60 Stepping 3, GenuineIntel, user.timezone=Asia/Jerusalem, env.TEMP=C:\Users\SHIMIB~1\AppData\Local\Temp, sun.arch.data.model=64, env.EC2_HOME=f:\frameworks\ec2-api-tools-1.7.1.0, java.endorsed.dirs=c:\Program Files\Java\jdk1.8.0_25\jre\lib\endorsed, sun.cpu.isalist=amd64, env.HOMEDRIVE=C:, sun.jnu.encoding=Cp1252, file.encoding.pkg=sun.io, env.SYSTEMDRIVE=C:, file.separator=\, java.specification.name=Java Platform API Specification, java.class.version=52.0, org.slf4j.simpleLogger.defaultLogLevel=debug, user.country=GB, java.home=c:\Program Files\Java\jdk1.8.0_25\jre, env.APPDATA=C:\Users\Shimi Bandiel\AppData\Roaming, env.CONFIGSETROOT=C:\WINDOWS\ConfigSetRoot, env.PUBLIC=C:\Users\Public, java.vm.info=mixed mode, env.OS=Windows_NT, os.version=6.3, path.separator=;, java.vm.version=25.25-b02, env.COMMANDER_EXE=C:\utils\totalcmd\TOTALCMD64.EXE, env.ASL.LOG=Destination=file, user.variant=, env.USERPROFILE=C:\Users\Shimi Bandiel, env.=F:=f:\Dropbox\Hibernate, env.JAVA_HOME=c:\Program Files\Java\jdk1.8.0_25, java.awt.printerjob=sun.awt.windows.WPrinterJob, env.TMP=C:\Users\SHIMIB~1\AppData\Local\Temp, env.PROGRAMFILES=C:\Program Files, sun.io.unicode.encoding=UnicodeLittle, awt.toolkit=sun.awt.windows.WToolkit, user.script=, user.home=C:\Users\Shimi Bandiel, env.COMMONPROGRAMFILES=C:\Program Files\Common Files, env.=EXITCODE=00000000, env.SESSIONNAME=Console, java.specification.vendor=Oracle Corporation, env.M2_HOME=f:\frameworks\apache-maven-3.2.1, java.library.path=c:\Program Files\Java\jdk1.8.0_25\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files\Haskell\bin;C:\Program Files\Haskell Platform\2014.2.0.0\lib\extralibs\bin;C:\Program Files\Haskell Platform\2014.2.0.0\bin;C:\Program Files (x86)\Chez Scheme Version 8.4\bin\i3nt;C:\ProgramData\Oracle\Java\javapath;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;c:\Program Files (x86)\scala\bin\;C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Windows Live\Shared;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\sbt\\bin;c:\Python27;f:\frameworks\graphviz-2.38\release\bin;C:\HashiCorp\Vagrant\bin;C:\opscode\chefdk\bin;C:\Program Files\Haskell Platform\2014.2.0.0\mingw\bin;C:\Program Files\nodejs\;C:\Program Files (x86)\Skype\Phone\;C:\Users\Shimi Bandiel\AppData\Roaming\cabal\bin;C:\Program Files\Boot2Docker for Windows;C:\Users\Shimi Bandiel\AppData\Roaming\npm;f:\frameworks\apache-maven-3.2.1\bin;f:\tools;., env.NUMBER_OF_PROCESSORS=8, java.vendor.url=http://java.oracle.com/, env.COMMONPROGRAMFILES(X86)=C:\Program Files (x86)\Common Files, env.PSMODULEPATH=C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules\, env.CLASSWORLDS_LAUNCHER=org.codehaus.plexus.classworlds.launcher.Launcher, env.MAVEN_CMD_LINE_ARGS=-X clean install, java.vm.vendor=Oracle Corporation, maven.home=f:\frameworks\apache-maven-3.2.1, java.runtime.name=Java(TM) SE Runtime Environment, sun.java.command=org.codehaus.plexus.classworlds.launcher.Launcher -X clean install, java.class.path=f:\frameworks\apache-maven-3.2.1\boot\plexus-classworlds-2.5.1.jar, env.PROGRAMW6432=C:\Program Files, maven.version=3.2.1, env.PROGRAMFILES(X86)=C:\Program Files (x86), env.MAVEN_JAVA_EXE="c:\Program Files\Java\jdk1.8.0_25\bin\java.exe", java.vm.specification.name=Java Virtual Machine Specification, env.LOGONSERVER=\\MicrosoftAccount, java.vm.specification.version=1.8, env.PROCESSOR_ARCHITECTURE=AMD64, env.COMMONPROGRAMW6432=C:\Program Files\Common Files, sun.cpu.endian=little, sun.os.patch.level=, env.HOME=C:\Users\Shimi Bandiel, java.io.tmpdir=C:\Users\SHIMIB~1\AppData\Local\Temp\, env.PROCESSOR_REVISION=3c03, env.VBOX_INSTALL_PATH=C:\Program Files\Oracle\VirtualBox\, java.vendor.url.bug=http://bugreport.sun.com/bugreport/, env.PROGRAMDATA=C:\ProgramData, env.COMSPEC=C:\WINDOWS\system32\cmd.exe, os.arch=amd64, java.awt.graphicsenv=sun.awt.Win32GraphicsEnvironment, java.ext.dirs=c:\Program Files\Java\jdk1.8.0_25\jre\lib\ext;C:\WINDOWS\Sun\Java\lib\ext, user.dir=C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec, env.LOCALAPPDATA=C:\Users\Shimi Bandiel\AppData\Local, line.separator=
, env.CLASSWORLDS_JAR="f:\frameworks\apache-maven-3.2.1\boot\plexus-classworlds-2.5.1.jar", java.vm.name=Java HotSpot(TM) 64-Bit Server VM, env.PATHEXT=.COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC, env.M2=f:\frameworks\apache-maven-3.2.1\bin, env.ERROR_CODE=0, env.USERNAME=Shimi Bandiel, sun.stderr.encoding=cp437, file.encoding=Cp1252, env.USERDOMAIN=TFWO, env.COMMANDER_INI=C:\Users\Shimi Bandiel\AppData\Roaming\GHISLER\wincmd.ini, java.specification.version=1.8, env.=C:=C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec, env.PROCESSOR_LEVEL=6}
[WARNING] Using platform encoding (Cp1252 actually) to copy filtered resources, i.e. build is platform dependent!
[DEBUG] resource with targetPath null
directory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\test\resources
excludes []
includes []
[INFO] skip non existing resourceDirectory C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\test\resources
[DEBUG] no use filter components
[INFO] 
[INFO] --- maven-compiler-plugin:2.5.1:testCompile (default-testCompile) @ MyTest ---
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-compiler-plugin:2.5.1:testCompile from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-compiler-plugin:2.5.1, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-compiler-plugin:2.5.1:testCompile' with basic configurator -->
[DEBUG]   (f) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (f) buildDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG]   (f) classpathElements = [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes, C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes]
[DEBUG]   (f) compileSourceRoots = [C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\test\java]
[DEBUG]   (f) compilerId = javac
[DEBUG]   (f) debug = true
[DEBUG]   (f) failOnError = true
[DEBUG]   (f) fork = false
[DEBUG]   (f) generatedTestSourcesDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\generated-test-sources\test-annotations
[DEBUG]   (f) optimize = false
[DEBUG]   (f) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes
[DEBUG]   (f) outputFileName = MyTest-1.0-SNAPSHOT
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) showDeprecation = false
[DEBUG]   (f) showWarnings = false
[DEBUG]   (f) source = 1.5
[DEBUG]   (f) staleMillis = 0
[DEBUG]   (f) target = 1.5
[DEBUG]   (f) verbose = false
[DEBUG] -- end configuration --
[DEBUG] Using compiler 'javac'.
[INFO] No sources to compile
[INFO] 
[INFO] --- maven-surefire-plugin:2.12.4:test (default-test) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=132, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=27, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=77, DefaultDependencyCollector.collectTime=52, DefaultDependencyCollector.transformTime=2}
[DEBUG] org.apache.maven.plugins:maven-surefire-plugin:jar:2.12.4:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.9:compile
[DEBUG]    org.apache.maven.surefire:surefire-booter:jar:2.12.4:compile
[DEBUG]       org.apache.maven.surefire:surefire-api:jar:2.12.4:compile
[DEBUG]    org.apache.maven.surefire:maven-surefire-common:jar:2.12.4:compile
[DEBUG]       org.apache.commons:commons-lang3:jar:3.1:compile
[DEBUG]       org.apache.maven.shared:maven-common-artifact-filters:jar:1.3:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:3.0.8:compile
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.9:compile
[DEBUG]    org.apache.maven:maven-project:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-settings:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-model:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-artifact-manager:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-plugin-registry:jar:2.0.9:compile
[DEBUG]       org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]          junit:junit:jar:3.8.1:test
[DEBUG]    org.apache.maven:maven-core:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.9:compile
[DEBUG]       org.apache.maven.reporting:maven-reporting-api:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-repository-metadata:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-error-diagnostics:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-plugin-descriptor:jar:2.0.9:compile
[DEBUG]       org.apache.maven:maven-monitor:jar:2.0.9:compile
[DEBUG]       classworlds:classworlds:jar:1.1:compile
[DEBUG]    org.apache.maven:maven-toolchain:jar:2.0.9:compile
[DEBUG]    org.apache.maven.plugin-tools:maven-plugin-annotations:jar:3.1:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-surefire-plugin:2.12.4
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-surefire-plugin:2.12.4
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-surefire-plugin:2.12.4
[DEBUG]   Included: org.apache.maven.plugins:maven-surefire-plugin:jar:2.12.4
[DEBUG]   Included: org.apache.maven.surefire:surefire-booter:jar:2.12.4
[DEBUG]   Included: org.apache.maven.surefire:surefire-api:jar:2.12.4
[DEBUG]   Included: org.apache.maven.surefire:maven-surefire-common:jar:2.12.4
[DEBUG]   Included: org.apache.commons:commons-lang3:jar:3.1
[DEBUG]   Included: org.apache.maven.shared:maven-common-artifact-filters:jar:1.3
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:3.0.8
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-api:jar:2.0.9
[DEBUG]   Included: org.apache.maven.plugin-tools:maven-plugin-annotations:jar:3.1
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.9
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG]   Excluded: junit:junit:jar:3.8.1
[DEBUG]   Excluded: org.apache.maven:maven-core:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-error-diagnostics:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-plugin-descriptor:jar:2.0.9
[DEBUG]   Excluded: org.apache.maven:maven-monitor:jar:2.0.9
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1
[DEBUG]   Excluded: org.apache.maven:maven-toolchain:jar:2.0.9
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-surefire-plugin:2.12.4:test from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-surefire-plugin:2.12.4, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-surefire-plugin:2.12.4:test' with basic configurator -->
[DEBUG]   (s) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (s) childDelegation = false
[DEBUG]   (s) classesDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG]   (s) disableXmlReport = false
[DEBUG]   (s) enableAssertions = true
[DEBUG]   (s) forkMode = once
[DEBUG]   (s) junitArtifactName = junit:junit
[DEBUG]   (s) localRepository =        id: local
      url: file:///C:/Users/Shimi%20Bandiel/.m2/repository/
   layout: default
snapshots: [enabled => true, update => always]
 releases: [enabled => true, update => always]

[DEBUG]   (f) parallelMavenExecution = false
[DEBUG]   (s) perCoreThreadCount = true
[DEBUG]   (s) pluginArtifactMap = {org.apache.maven.plugins:maven-surefire-plugin=org.apache.maven.plugins:maven-surefire-plugin:maven-plugin:2.12.4:, org.apache.maven.surefire:surefire-booter=org.apache.maven.surefire:surefire-booter:jar:2.12.4:compile, org.apache.maven.surefire:surefire-api=org.apache.maven.surefire:surefire-api:jar:2.12.4:compile, org.apache.maven.surefire:maven-surefire-common=org.apache.maven.surefire:maven-surefire-common:jar:2.12.4:compile, org.apache.commons:commons-lang3=org.apache.commons:commons-lang3:jar:3.1:compile, org.apache.maven.shared:maven-common-artifact-filters=org.apache.maven.shared:maven-common-artifact-filters:jar:1.3:compile, org.codehaus.plexus:plexus-utils=org.codehaus.plexus:plexus-utils:jar:3.0.8:compile, org.apache.maven.reporting:maven-reporting-api=org.apache.maven.reporting:maven-reporting-api:jar:2.0.9:compile, org.apache.maven.plugin-tools:maven-plugin-annotations=org.apache.maven.plugin-tools:maven-plugin-annotations:jar:3.1:compile}
[DEBUG]   (f) pluginDescriptor = Component Descriptor: role: 'org.apache.maven.plugin.Mojo', implementation: 'org.apache.maven.plugin.surefire.HelpMojo', role hint: 'org.apache.maven.plugins:maven-surefire-plugin:2.12.4:help'
role: 'org.apache.maven.plugin.Mojo', implementation: 'org.apache.maven.plugin.surefire.SurefirePlugin', role hint: 'org.apache.maven.plugins:maven-surefire-plugin:2.12.4:test'
---
[DEBUG]   (s) printSummary = true
[DEBUG]   (s) projectArtifactMap = {}
[DEBUG]   (s) redirectTestOutputToFile = false
[DEBUG]   (s) remoteRepositories = [       id: central
      url: http://repo.maven.apache.org/maven2
   layout: default
snapshots: [enabled => false, update => daily]
 releases: [enabled => true, update => never]
]
[DEBUG]   (s) reportFormat = brief
[DEBUG]   (s) reportsDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\surefire-reports
[DEBUG]   (s) runOrder = filesystem
[DEBUG]   (s) skip = false
[DEBUG]   (s) skipTests = false
[DEBUG]   (s) testClassesDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\test-classes
[DEBUG]   (s) testFailureIgnore = false
[DEBUG]   (s) testNGArtifactName = org.testng:testng
[DEBUG]   (s) testSourceDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\src\test\java
[DEBUG]   (s) trimStackTrace = true
[DEBUG]   (s) useFile = true
[DEBUG]   (s) useManifestOnlyJar = true
[DEBUG]   (s) useSystemClassLoader = true
[DEBUG]   (s) useUnlimitedThreads = false
[DEBUG]   (s) workingDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (s) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (s) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG] -- end configuration --
[INFO] No tests to run.
[INFO] 
[INFO] --- exec-maven-plugin:1.2.1:exec (second) @ MyTest ---
[DEBUG] Configuring mojo org.codehaus.mojo:exec-maven-plugin:1.2.1:exec from plugin realm ClassRealm[plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.codehaus.mojo:exec-maven-plugin:1.2.1:exec' with basic configurator -->
[DEBUG]   (f) arguments = [-sjava, -o, -djad2, ./**/*.class]
[DEBUG]   (f) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (f) classpathScope = runtime
[DEBUG]   (f) executable = f:\\tools\\jad.exe
[DEBUG]   (f) longClasspath = false
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) skip = false
[DEBUG]   (f) workingDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] -- end configuration --
[DEBUG] Toolchains are ignored, 'executable' parameter is set to f:\\tools\\jad.exe
[DEBUG] Executing command line: f:\tools\jad.exe -sjava -o -djad2 ./**/*.class
[INFO] 
[INFO] --- exec-maven-plugin:1.2.1:exec (third) @ MyTest ---
[DEBUG] Configuring mojo org.codehaus.mojo:exec-maven-plugin:1.2.1:exec from plugin realm ClassRealm[plugin>org.codehaus.mojo:exec-maven-plugin:1.2.1, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.codehaus.mojo:exec-maven-plugin:1.2.1:exec' with basic configurator -->
[DEBUG]   (f) arguments = [jad, jad2]
[DEBUG]   (f) basedir = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec
[DEBUG]   (f) classpathScope = runtime
[DEBUG]   (f) executable = c:\Program Files (x86)\GnuWin32\bin\diff.exe
[DEBUG]   (f) longClasspath = false
[DEBUG]   (f) outputFile = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\TailOptReport.txt
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) skip = false
[DEBUG]   (s) successCodes = [0, 1]
[DEBUG]   (f) workingDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG] -- end configuration --
[DEBUG] Toolchains are ignored, 'executable' parameter is set to c:\Program Files (x86)\GnuWin32\bin\diff.exe
[DEBUG] Executing command line: c:\Program Files (x86)\GnuWin32\bin\diff.exe jad jad2
diff jad/MyFactorial.java jad2/MyFactorial.java
19,22c19,25
<         if(n <= 1)
<             return acc;
<         else
<             return factorial(acc * n, n - 1);
---
>         do
>         {
>             if(n <= 1)
>                 return acc;
>             n--;
>             acc = acc * n;
>         } while(true);
diff jad/ShowRec.java jad2/ShowRec.java
19,22c19,25
<         if(x == 0)
<             return n;
<         else
<             return add(n + 1, x - 1);
---
>         do
>         {
>             if(x == 0)
>                 return n;
>             x--;
>             n = n + 1;
>         } while(true);
[INFO] 
[INFO] --- maven-jar-plugin:2.4:jar (default-jar) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=0, ConflictMarker.markTime=0, ConflictMarker.nodeCount=74, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=28, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=1, ConflictResolver.conflictItemCount=70, DefaultDependencyCollector.collectTime=15, DefaultDependencyCollector.transformTime=1}
[DEBUG] org.apache.maven.plugins:maven-jar-plugin:jar:2.4:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-project:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-settings:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-artifact-manager:jar:2.0.6:compile
[DEBUG]          org.apache.maven:maven-repository-metadata:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-registry:jar:2.0.6:compile
[DEBUG]       org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]          junit:junit:jar:3.8.1:compile
[DEBUG]          classworlds:classworlds:jar:1.1-alpha-2:compile
[DEBUG]    org.apache.maven:maven-model:jar:2.0.6:runtime
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-archiver:jar:2.5:compile
[DEBUG]       org.apache.maven:maven-core:jar:2.0.6:compile
[DEBUG]          org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6:compile
[DEBUG]          org.apache.maven.reporting:maven-reporting-api:jar:2.0.6:compile
[DEBUG]             org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7:compile
[DEBUG]          org.apache.maven:maven-error-diagnostics:jar:2.0.6:compile
[DEBUG]          commons-cli:commons-cli:jar:1.0:compile
[DEBUG]          org.apache.maven:maven-plugin-descriptor:jar:2.0.6:compile
[DEBUG]          org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4:compile
[DEBUG]          org.apache.maven:maven-monitor:jar:2.0.6:compile
[DEBUG]       org.codehaus.plexus:plexus-interpolation:jar:1.15:compile
[DEBUG]    org.codehaus.plexus:plexus-archiver:jar:2.1:compile
[DEBUG]       org.codehaus.plexus:plexus-io:jar:2.0.2:compile
[DEBUG]    commons-lang:commons-lang:jar:2.1:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:3.0:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-jar-plugin:2.4
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-jar-plugin:2.4
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-jar-plugin:2.4
[DEBUG]   Included: org.apache.maven.plugins:maven-jar-plugin:jar:2.4
[DEBUG]   Included: junit:junit:jar:3.8.1
[DEBUG]   Included: org.apache.maven:maven-archiver:jar:2.5
[DEBUG]   Included: org.apache.maven.reporting:maven-reporting-api:jar:2.0.6
[DEBUG]   Included: org.apache.maven.doxia:doxia-sink-api:jar:1.0-alpha-7
[DEBUG]   Included: commons-cli:commons-cli:jar:1.0
[DEBUG]   Included: org.codehaus.plexus:plexus-interactivity-api:jar:1.0-alpha-4
[DEBUG]   Included: org.codehaus.plexus:plexus-interpolation:jar:1.15
[DEBUG]   Included: org.codehaus.plexus:plexus-archiver:jar:2.1
[DEBUG]   Included: org.codehaus.plexus:plexus-io:jar:2.0.2
[DEBUG]   Included: commons-lang:commons-lang:jar:2.1
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:3.0
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.6
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1-alpha-2
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-core:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-parameter-documenter:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-error-diagnostics:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-descriptor:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-monitor:jar:2.0.6
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-jar-plugin:2.4:jar from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-jar-plugin:2.4, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-jar-plugin:2.4:jar' with basic configurator -->
[DEBUG]   (f) classesDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes
[DEBUG]   (f) defaultManifestFile = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\classes\META-INF\MANIFEST.MF
[DEBUG]   (f) finalName = MyTest-1.0-SNAPSHOT
[DEBUG]   (f) forceCreation = false
[DEBUG]   (f) outputDirectory = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target
[DEBUG]   (f) project = MavenProject: com.bom:MyTest:1.0-SNAPSHOT @ C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (f) session = org.apache.maven.execution.MavenSession@79145d5a
[DEBUG]   (f) skipIfEmpty = false
[DEBUG]   (f) useDefaultManifestFile = false
[DEBUG] -- end configuration --
[DEBUG] isUp2date: false (Destination C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\MyTest-1.0-SNAPSHOT.jar not found.)
[INFO] Building jar: C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\MyTest-1.0-SNAPSHOT.jar
[DEBUG] adding directory META-INF/
[DEBUG] adding entry META-INF/MANIFEST.MF
[DEBUG] adding directory com/
[DEBUG] adding directory jad/
[DEBUG] adding directory jad2/
[DEBUG] adding entry com/MyFactorial.class
[DEBUG] adding entry com/ShowRec.class
[DEBUG] adding entry jad/MyFactorial.java
[DEBUG] adding entry jad/ShowRec.java
[DEBUG] adding entry jad2/MyFactorial.java
[DEBUG] adding entry jad2/ShowRec.java
[DEBUG] adding directory META-INF/maven/
[DEBUG] adding directory META-INF/maven/com.bom/
[DEBUG] adding directory META-INF/maven/com.bom/MyTest/
[DEBUG] adding entry META-INF/maven/com.bom/MyTest/pom.xml
[DEBUG] adding entry META-INF/maven/com.bom/MyTest/pom.properties
[INFO] 
[INFO] --- maven-install-plugin:2.4:install (default-install) @ MyTest ---
[DEBUG] Dependency collection stats: {ConflictMarker.analyzeTime=1, ConflictMarker.markTime=0, ConflictMarker.nodeCount=38, ConflictIdSorter.graphTime=0, ConflictIdSorter.topsortTime=0, ConflictIdSorter.conflictIdCount=15, ConflictIdSorter.conflictIdCycleCount=0, ConflictResolver.totalTime=0, ConflictResolver.conflictItemCount=35, DefaultDependencyCollector.collectTime=11, DefaultDependencyCollector.transformTime=1}
[DEBUG] org.apache.maven.plugins:maven-install-plugin:jar:2.4:
[DEBUG]    org.apache.maven:maven-plugin-api:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-project:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-settings:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-profile:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-plugin-registry:jar:2.0.6:compile
[DEBUG]       org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1:compile
[DEBUG]          junit:junit:jar:3.8.1:compile
[DEBUG]          classworlds:classworlds:jar:1.1-alpha-2:compile
[DEBUG]    org.apache.maven:maven-model:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-artifact-manager:jar:2.0.6:compile
[DEBUG]       org.apache.maven:maven-repository-metadata:jar:2.0.6:compile
[DEBUG]    org.apache.maven:maven-artifact:jar:2.0.6:compile
[DEBUG]    org.codehaus.plexus:plexus-utils:jar:3.0.5:compile
[DEBUG]    org.codehaus.plexus:plexus-digest:jar:1.0:compile
[DEBUG] Created new class realm plugin>org.apache.maven.plugins:maven-install-plugin:2.4
[DEBUG] Importing foreign packages into class realm plugin>org.apache.maven.plugins:maven-install-plugin:2.4
[DEBUG]   Imported:  < maven.api
[DEBUG] Populating class realm plugin>org.apache.maven.plugins:maven-install-plugin:2.4
[DEBUG]   Included: org.apache.maven.plugins:maven-install-plugin:jar:2.4
[DEBUG]   Included: junit:junit:jar:3.8.1
[DEBUG]   Included: org.codehaus.plexus:plexus-utils:jar:3.0.5
[DEBUG]   Included: org.codehaus.plexus:plexus-digest:jar:1.0
[DEBUG]   Excluded: org.apache.maven:maven-plugin-api:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-project:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-settings:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-profile:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-plugin-registry:jar:2.0.6
[DEBUG]   Excluded: org.codehaus.plexus:plexus-container-default:jar:1.0-alpha-9-stable-1
[DEBUG]   Excluded: classworlds:classworlds:jar:1.1-alpha-2
[DEBUG]   Excluded: org.apache.maven:maven-model:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact-manager:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-repository-metadata:jar:2.0.6
[DEBUG]   Excluded: org.apache.maven:maven-artifact:jar:2.0.6
[DEBUG] Configuring mojo org.apache.maven.plugins:maven-install-plugin:2.4:install from plugin realm ClassRealm[plugin>org.apache.maven.plugins:maven-install-plugin:2.4, parent: sun.misc.Launcher$AppClassLoader@5c647e05]
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-install-plugin:2.4:install' with basic configurator -->
[DEBUG]   (f) artifact = com.bom:MyTest:jar:1.0-SNAPSHOT
[DEBUG]   (f) attachedArtifacts = []
[DEBUG]   (f) createChecksum = false
[DEBUG]   (f) localRepository =        id: local
      url: file:///C:/Users/Shimi%20Bandiel/.m2/repository/
   layout: default
snapshots: [enabled => true, update => always]
 releases: [enabled => true, update => always]

[DEBUG]   (f) packaging = jar
[DEBUG]   (f) pomFile = C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml
[DEBUG]   (s) skip = false
[DEBUG]   (f) updateReleaseInfo = false
[DEBUG] -- end configuration --
[INFO] Installing C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\target\MyTest-1.0-SNAPSHOT.jar to C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\1.0-SNAPSHOT\MyTest-1.0-SNAPSHOT.jar
[DEBUG] Writing tracking file C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\1.0-SNAPSHOT\_remote.repositories
[INFO] Installing C:\Users\Shimi Bandiel\maven_course_workspace\ShowRec\pom.xml to C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\1.0-SNAPSHOT\MyTest-1.0-SNAPSHOT.pom
[DEBUG] Writing tracking file C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\1.0-SNAPSHOT\_remote.repositories
[DEBUG] Installing com.bom:MyTest:1.0-SNAPSHOT/maven-metadata.xml to C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\1.0-SNAPSHOT\maven-metadata-local.xml
[DEBUG] Installing com.bom:MyTest/maven-metadata.xml to C:\Users\Shimi Bandiel\.m2\repository\com\bom\MyTest\maven-metadata-local.xml
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 2.041 s
[INFO] Finished at: 2015-08-12T12:15:06+02:00
[INFO] Final Memory: 16M/167M
[INFO] ------------------------------------------------------------------------
