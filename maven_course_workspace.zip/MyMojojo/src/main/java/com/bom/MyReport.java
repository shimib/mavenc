package com.bom;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Locale;

import org.apache.maven.doxia.sink.Sink;
import org.apache.maven.doxia.sink.SinkEventAttributeSet;
import org.apache.maven.doxia.sink.SinkEventAttributes;
import org.apache.maven.doxia.siterenderer.Renderer;
import org.apache.maven.project.MavenProject;
import org.apache.maven.reporting.AbstractMavenReport;
import org.apache.maven.reporting.MavenReportException;
/**
* Goal that performs tail-rec optimizations
* 
* @goal tail-rec-report
* 
* @phase cls
* 
*/
public class MyReport extends AbstractMavenReport{

	/**
     * Directory where reports will go.
     *
     * @parameter expression="${project.reporting.outputDirectory}"
     * @required
     * @readonly
     */
    private String outputDirectory;
 
    /**
     * @parameter default-value="${project}"
     * @required
     * @readonly
     */
    private MavenProject project;
 
    /**
     * @component
     * @required
     * @readonly
     */
    private Renderer siteRenderer;
	
	
	@Override
	public String getDescription(Locale arg0) {
		return "Show Tail Call Optimization Report";
	}

	@Override
	public String getName(Locale arg0) {
		return "TailCallOptimization";
	}

	@Override
	public String getOutputName() {
		return "TailCallReport";
	}

	@Override
	protected void executeReport(Locale arg0) throws MavenReportException {
		
		Sink s = getSink();
		
		
		s.body();
		s.paragraph();
		SinkEventAttributeSet left = new SinkEventAttributeSet();
		left.addAttribute(SinkEventAttributeSet.ITALIC, true);
		SinkEventAttributeSet right = new SinkEventAttributeSet();
		right.addAttribute(SinkEventAttributeSet.LINETHROUGH, true);
		try {
			BufferedReader br = new BufferedReader(new FileReader("TailOptReport.txt"));
			String line = null;
			while((line = br.readLine()) != null) {
				if (line.startsWith("diff")) {
					s.paragraph_();
					s.paragraph();
					s.bold();
					s.text(line.substring(line.lastIndexOf('/')+1));
					s.bold_();
					s.lineBreak();
					s.lineBreak();
					s.lineBreak();
				} else {
					if (line.startsWith("<")) {
						s.text(line.substring(1),left);
						s.lineBreak();
					}
					if (line.startsWith(">")) {
						s.text(line.substring(1),right);
						s.lineBreak();
					}
				}
				
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		s.paragraph_();
		s.body_();
		s.close();
	}

	@Override
	protected String getOutputDirectory() {
		return outputDirectory;
	}

	@Override
	protected MavenProject getProject() {
		return project;
	}

	@Override
	protected Renderer getSiteRenderer() {
		return siteRenderer;
	}

}
